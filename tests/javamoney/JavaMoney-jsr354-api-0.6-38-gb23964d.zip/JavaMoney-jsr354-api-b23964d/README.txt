JSR 354: Money and Currency API
=========
JSR 354 provides an API for representing, transporting, and performing comprehensive calculations with Money and Currency. 
See the home page for more details:
http://jcp.org/en/jsr/detail?id=354

This is the API module of JSR 354.

See also:
http://javamoney.github.io/jsr354-api/

