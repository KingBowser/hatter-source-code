﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CommonScriptEnginer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private ScriptObject CaculateSum(ScriptEnvironment environment, ScriptObject[] param)
        {
            double sum = 0;
            foreach (ScriptObject p in param)
            {
                sum += p.NumberValue;
            }
            return new ScriptObject(ObjectType.Number, sum);
        }

        private ScriptObject CaculateSqrt(ScriptEnvironment environment, ScriptObject[] param)
        {
            return new ScriptObject(ObjectType.Number, Math.Sqrt(param[0].NumberValue));
        }

        private ScriptObject Alert(ScriptEnvironment environment, ScriptObject[] param)
        {
            MessageBox.Show(param[0].StringValue);
            return ScriptObject.Undefined;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                ScriptEnvironment environment = ScriptDefaultEnvironment.MakeEnvironment();

                ScriptBlock block = ScriptFileLoader.LoadScriptBlock(textBox1.Text);

                ScriptExpressionExecutor.executeBlock(environment, block);

                /*
                string[] expressions = textBox1.Text.Split('\n');

                for (int i = 0; i < expressions.Length; i++)
                {
                    ScriptExpression expression = ScriptExpressionParser.ParseExpression(expressions[i]);

                    ScriptExpressionExecutor executor = new ScriptExpressionExecutor(expression);

                    ScriptObject result = executor.execute(environment);
                }
                */
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
