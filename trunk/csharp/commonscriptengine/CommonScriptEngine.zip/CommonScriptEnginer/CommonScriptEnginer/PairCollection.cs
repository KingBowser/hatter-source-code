﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class PairCollection<K, V>
    {
        protected Hashtable collection;

        public PairCollection()
        {
            collection = new Hashtable();
        }

        public bool HasKey(K key)
        {
            return collection.ContainsKey(key);
        }

        public V GetValue(K key)
        {
            return (V)collection[key];
        }

        public void SetValue(K key, V value)
        {
            collection[key] = value;
        }

        public bool AddPair(K key, V value)
        {
            if (HasKey(key))
            {
                return false;
            }
            else
            {
                collection[key] = value;
                return true;
            }
        }

        public bool RemovePair(K key, V value)
        {
            if (HasKey(key))
            {
                collection.Remove(key); return true;
            }
            else
            {
                return false;
            }
        }
    }
}
