﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class ScriptBlock
    {
        private Hashtable labelTable = new Hashtable();

        private List<ScriptLine> scriptLines = new List<ScriptLine>();

        public ScriptBlock(List<ScriptLine> scriptLines, Hashtable labelTable)
        {
            this.scriptLines = scriptLines;
            this.labelTable = labelTable;
        }

        public List<ScriptLine> ScriptLines
        {
            get { return scriptLines; }
        }

        public int GetLineNumber(string label)
        {
            if (!label.EndsWith(":"))
            {
                label = label + ":";
            }
            return (labelTable.ContainsKey(label)) ? (int)labelTable[label] : -1;
        }
    }
}
