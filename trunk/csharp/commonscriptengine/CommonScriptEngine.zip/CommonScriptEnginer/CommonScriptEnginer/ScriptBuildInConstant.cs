﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class ScriptBuildInConstant
    {
        private ScriptBuildInConstant()
        {
        }

        // = Math ============================================================================= //

        public static ScriptObject PI = new ScriptObject(ObjectType.Number,  Math.PI);

        public static ScriptObject E = new ScriptObject(ObjectType.Number, Math.E);
    }
}
