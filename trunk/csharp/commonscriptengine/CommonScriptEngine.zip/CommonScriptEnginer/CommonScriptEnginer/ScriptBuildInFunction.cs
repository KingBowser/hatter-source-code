﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class ScriptBuildInFunction
    {
        private ScriptBuildInFunction()
        {
        }

        // checking ...
        private static void CheckParamCount(string funcName, ScriptObject[] param, int count)
        {
            if (param.Length != count)
            {
                throw new ScriptException("'" + funcName + "' should have " + count + " parameter(s).");
            }
        }

        private static void CheckParamLeastCount(string funcName, ScriptObject[] param, int leastCount)
        {
            if (param.Length < leastCount)
            {
                throw new ScriptException("'" + funcName + "' should have more  " + (leastCount - 1) + " parameter(s).");
            }
        }

        // = Math ============================================================================= //

        public static ScriptObject Sum(ScriptEnvironment environment, ScriptObject[] param)
        {
            double sum = 0;
            foreach (ScriptObject p in param)
            {
                sum += p.NumberValue;
            }
            return new ScriptObject(ObjectType.Number, sum);
        }

        public static ScriptObject Power(ScriptEnvironment environment, ScriptObject[] param)
        {
            CheckParamCount("power", param, 2);
            return new ScriptObject(ObjectType.Number, (Math.Pow(param[0].NumberValue, param[1].NumberValue)));
        }

        public static ScriptObject Sqrt(ScriptEnvironment environment, ScriptObject[] param)
        {
            CheckParamCount("sqrt", param, 1);
            return new ScriptObject(ObjectType.Number, Math.Sqrt(param[0].NumberValue));
        }

        // = Logic ============================================================================= //

        public static ScriptObject And(ScriptEnvironment environment, ScriptObject[] param)
        {
            CheckParamLeastCount("and", param, 1);
            foreach (ScriptObject p in param)
            {
                if (!p.IsTrue)
                {
                    return ScriptObject.False;
                }
            }
            return ScriptObject.True;
        }

        public static ScriptObject Or(ScriptEnvironment environment, ScriptObject[] param)
        {
            CheckParamLeastCount("and", param, 1);
            foreach (ScriptObject p in param)
            {
                if (p.IsTrue)
                {
                    return ScriptObject.True;
                }
            }
            return ScriptObject.False;
        }

        public static ScriptObject Not(ScriptEnvironment environment, ScriptObject[] param)
        {
            CheckParamCount("not", param, 1);
            return new ScriptObject(ObjectType.Boolean, !param[0].IsTrue);
        }

        // = Bit ============================================================================= //

        public static ScriptObject BitAnd(ScriptEnvironment environment, ScriptObject[] param)
        {
            CheckParamCount("bitAnd", param, 2);
            return new ScriptObject(ObjectType.Number, (param[0].IntegerValue & param[1].IntegerValue));
        }

        public static ScriptObject BitOr(ScriptEnvironment environment, ScriptObject[] param)
        {
            CheckParamCount("bitOr", param, 2);
            return new ScriptObject(ObjectType.Number, (param[0].IntegerValue | param[1].IntegerValue));
        }

        public static ScriptObject BitXor(ScriptEnvironment environment, ScriptObject[] param)
        {
            CheckParamCount("bitXor", param, 2);
            return new ScriptObject(ObjectType.Number, (param[0].IntegerValue ^ param[1].IntegerValue));
        }

        public static ScriptObject BitNot(ScriptEnvironment environment, ScriptObject[] param)
        {
            CheckParamCount("bitNot", param, 1);
            return new ScriptObject(ObjectType.Number, (~param[0].IntegerValue));
        }

        public static ScriptObject BitLeft(ScriptEnvironment environment, ScriptObject[] param)
        {
            CheckParamCount("bitLeft", param, 2);
            return new ScriptObject(ObjectType.Number, (param[0].IntegerValue << param[1].IntegerValue));
        }

        public static ScriptObject BitRight(ScriptEnvironment environment, ScriptObject[] param)
        {
            CheckParamCount("bitRight", param, 2);
            return new ScriptObject(ObjectType.Number, (param[0].IntegerValue >> param[1].IntegerValue));
        }

        // = Misc ============================================================================= //

        public static ScriptObject Alert(ScriptEnvironment environment, ScriptObject[] param)
        {
            CheckParamCount("alert", param, 1);
            MessageBox.Show(param[0].StringValue, "Alert");
            return ScriptObject.Undefined;
        }

        public static ScriptObject Confirm(ScriptEnvironment environment, ScriptObject[] param)
        {
            CheckParamCount("conifrm", param, 1);
            DialogResult result = MessageBox.Show(param[0].StringValue, "Confirm", MessageBoxButtons.OKCancel);
            return (result == DialogResult.OK) ? ScriptObject.True : ScriptObject.False;
        }

        public static ScriptObject Exit(ScriptEnvironment environment, ScriptObject[] param)
        {
            Application.Exit();
            return ScriptObject.Undefined;
        }

        // = Misc ============================================================================= //

        public static ScriptObject ToHex(ScriptEnvironment environment, ScriptObject[] param)
        {
            CheckParamCount("toHex", param, 1);
            return new ScriptObject(ObjectType.String, "0x" + param[0].IntegerValue.ToString("X"));
        }
    }
}
