﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class ScriptDefaultEnvironment
    {
        private ScriptDefaultEnvironment()
        {
        }

        public static ScriptEnvironment MakeEnvironment()
        {
            ScriptEnvironment environment = new ScriptEnvironment();

            // constant
            environment.GlobalConstant.SetValue("PI", ScriptBuildInConstant.PI);
            environment.GlobalConstant.SetValue("E", ScriptBuildInConstant.E);

            // function
            environment.Function.AddFunction(new ScriptFunction("alert", ScriptBuildInFunction.Alert));
            environment.Function.AddFunction(new ScriptFunction("confirm", ScriptBuildInFunction.Confirm));
            environment.Function.AddFunction(new ScriptFunction("sum", ScriptBuildInFunction.Sum));
            environment.Function.AddFunction(new ScriptFunction("power", ScriptBuildInFunction.Power));
            environment.Function.AddFunction(new ScriptFunction("sqrt", ScriptBuildInFunction.Sqrt));
            environment.Function.AddFunction(new ScriptFunction("and", ScriptBuildInFunction.And));
            environment.Function.AddFunction(new ScriptFunction("or", ScriptBuildInFunction.Or));
            environment.Function.AddFunction(new ScriptFunction("not", ScriptBuildInFunction.Not));
            environment.Function.AddFunction(new ScriptFunction("bitAnd", ScriptBuildInFunction.BitAnd));
            environment.Function.AddFunction(new ScriptFunction("bitOr", ScriptBuildInFunction.BitOr));
            environment.Function.AddFunction(new ScriptFunction("bitXor", ScriptBuildInFunction.BitXor));
            environment.Function.AddFunction(new ScriptFunction("bitNot", ScriptBuildInFunction.BitNot));
            environment.Function.AddFunction(new ScriptFunction("bitLeft", ScriptBuildInFunction.BitLeft));
            environment.Function.AddFunction(new ScriptFunction("bitRight", ScriptBuildInFunction.BitRight));
            environment.Function.AddFunction(new ScriptFunction("exit", ScriptBuildInFunction.Exit));
            environment.Function.AddFunction(new ScriptFunction("toHex", ScriptBuildInFunction.ToHex));

            return environment;
        }
    }
}
