﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class ScriptEnvironment
    {
        private ScriptConstantCollection globalConstant;
        private ScriptConstantCollection currentConstant;
        private ScriptVariantCollection globalVariant;
        private ScriptVariantCollection currentVariant;
        private ScriptFunctionCollection function;

        public ScriptEnvironment()
        {
            this.globalConstant = new ScriptConstantCollection();
            this.currentConstant = new ScriptConstantCollection();
            this.globalVariant = new ScriptVariantCollection();
            this.currentVariant = new ScriptVariantCollection();
            this.function = new ScriptFunctionCollection();
        }

        public ScriptEnvironment(ScriptConstantCollection globalConstant, ScriptVariantCollection globalVariant, ScriptFunctionCollection function)
        {
            this.globalConstant = globalConstant;
            this.currentConstant = new ScriptConstantCollection();
            this.globalVariant = globalVariant;
            this.currentVariant = new ScriptVariantCollection();
            this.function = function;
        }

        public static ScriptEnvironment FromGlobalEnvironment(ScriptEnvironment environment){
            return new ScriptEnvironment(environment.GlobalConstant, environment.GlobalVariant, environment.Function);
        }

        public ScriptConstantCollection GlobalConstant
        {
            get { return globalConstant; }
        }

        public ScriptConstantCollection CurrentConstant
        {
            get { return currentConstant; }
        }

        public ScriptVariantCollection GlobalVariant
        {
            get { return globalVariant; }
        }

        public ScriptVariantCollection CurrentVariant
        {
            get { return currentVariant; }
        }

        public ScriptFunctionCollection Function
        {
            get { return function; }
        }

        public bool IsGlobalConstant(string key)
        {
            return this.globalConstant.HasKey(key);
        }

        public bool IsCurrentConstant(string key)
        {
            return this.currentConstant.HasKey(key);
        }

        public bool IsGlobalVariant(string key)
        {
            return this.globalVariant.HasKey(key);
        }

        public bool IsCurrentVariant(string key)
        {
            return this.currentVariant.HasKey(key);
        }

        public bool IsGlobal(string key)
        {
            return (IsGlobalConstant(key) || IsGlobalVariant(key));
        }

        public bool IsCurrent(string key)
        {
            return (IsCurrentConstant(key) || IsCurrentVariant(key));
        }

        public bool IsConstant(string key)
        {
            return (IsGlobalConstant(key) || IsCurrentConstant(key));
        }

        public bool IsVariant(string key)
        {
            return (IsGlobalVariant(key) || IsCurrentVariant(key));
        }

        public bool IsConstantOrVariant(string key)
        {
            return (IsConstant(key) || IsVariant(key));
        }

        public bool IsFunction(string key)
        {
            return function.HasKey(key);
        }

        public bool IsKnown(string key)
        {
            return (IsConstantOrVariant(key) || IsFunction(key));
        }

        public bool VarVariant(string key)
        {
            // only use current, because when in global scope current=global
            if (!IsCurrentVariant(key))
            {
                currentVariant.AddPair("key", ScriptObject.Undefined);
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool SetVariant(string key, ScriptObject value)
        {
            if ((!IsCurrentVariant(key)) && (IsGlobalVariant(key)))
            {
                globalVariant.SetValue(key, value);
            }
            currentVariant.SetValue(key, value);
            return true;
        }

        public ScriptObject GetValue(string key)
        {
            if (IsCurrentConstant(key))
            {
                return currentConstant.GetValue(key);
            }
            else if (IsGlobalConstant(key))
            {
                return globalConstant.GetValue(key);
            }
            else if (IsCurrentVariant(key))
            {
                return currentVariant.GetValue(key);
            }
            else if (IsGlobalVariant(key))
            {
                return globalVariant.GetValue(key);
            }
            else
            {
                return ScriptObject.Undefined;
            }
        }
    }
}
