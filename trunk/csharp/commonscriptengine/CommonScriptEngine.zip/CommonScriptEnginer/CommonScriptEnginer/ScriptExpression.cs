﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class ScriptExpression
    {
        protected Operation operation;

        protected string name;

        protected ScriptExpression express;

        protected ScriptExpression left;

        protected ScriptExpression right;

        protected ScriptExpression()
        {
        }

        public ScriptExpression(Operation operation)
        {
            this.operation = operation;
        }

        public ScriptExpression(Operation operation, ScriptExpression left, ScriptExpression right)
        {
            this.operation = operation;
            this.left = left;
            this.right = right;
        }

        public ScriptExpression(Operation operation, ScriptExpression express, ScriptExpression left, ScriptExpression right)
        {
            this.operation = operation;
            this.express = express;
            this.left = left;
            this.right = right;
        }

        public ScriptExpression(Operation operation, string name, ScriptExpression left, ScriptExpression right)
        {
            this.operation = operation;
            this.name = name;
            this.left = left;
            this.right = right;
        }

        public ScriptExpression(Operation operation, string name, ScriptExpression express, ScriptExpression left, ScriptExpression right)
        {
            this.operation = Operation;
            this.name = name;
            this.express = express;
            this.left = left;
            this.right = right;
        }

        public Operation Operation
        {
            get { return operation; }
        }

        public string Name
        {
            get { return name; }
        }

        public ScriptExpression Express
        {
            get { return express; }
        }

        public ScriptExpression Left
        {
            get { return left; }
        }

        public ScriptExpression Right
        {
            get { return right; }
        }

        public static readonly ScriptExpression EmptyExpression = new ScriptExpression(Operation.Empty);
    }
}
