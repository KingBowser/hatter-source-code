﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class ScriptExpressionExecutor
    {
        private ScriptExpression expression;

        public ScriptExpressionExecutor(string expression)
        {
            this.expression = ScriptExpressionParser.ParseExpression(expression);
        }

        public ScriptExpressionExecutor(ScriptExpression expression)
        {
            this.expression = expression;
        }

        public bool IsReturn()
        {
            return (expression.Operation == Operation.Return);
        }

        public static ScriptObject executeBlock(ScriptEnvironment environment, ScriptBlock block)
        {
            ScriptObject result = ScriptObject.Undefined;

            for (int i = 0; i < block.ScriptLines.Count; i++)
            {
               ScriptExpression expression =  ScriptExpressionParser.ParseExpression(block.ScriptLines[i].Line);

               try
               {
                   result = new ScriptExpressionExecutor(expression).execute(environment);
                   if (result is ScriptGoto)
                   {
                       i = block.GetLineNumber((result as ScriptGoto).Label);
                       if (i < 0)
                       {
                           throw new Exception("Error in goto.");
                       }
                   }
               }
               catch
               {
                   throw;
               }
            }

            return result;
        }

        public ScriptObject execute(ScriptEnvironment environment)
        {
            if (expression.Operation == Operation.Empty)
            {
                return ScriptObject.Undefined;
            }
            if (expression.Operation == Operation.Value)
            {
                return expression as ScriptObject;
            }
            if (expression.Operation == Operation.Function)
            {
                return executeFunction(environment);
            }
            if (expression.Operation == Operation.ConstVar)
            {
                return executeConstantVariant(environment);
            }
            if (expression.Operation == Operation.Return)
            {
                return new ScriptExpressionExecutor(expression.Right).execute(environment);
            }
            if (expression.Operation == Operation.Goto)
            {
                return new ScriptGoto(expression.Name);
            }

            if (expression.Operation == Operation.Equal)
            {
                if (expression.Left.Operation != Operation.ConstVar)
                {
                    throw new Exception("Left not var.");
                }
                if ((expression.Right.Operation == Operation.ConstVar) && (!environment.IsConstantOrVariant(expression.Right.Name))
                    && (environment.IsFunction(expression.Right.Name)))
                {
                    // because of the design, cannot use like: a = b = sqrt
                    environment.Function.SetValue(expression.Left.Name, environment.Function.GetValue(expression.Right.Name));
                    return ScriptObject.Undefined;
                }
                else
                {
                    ScriptObject rightObject = new ScriptExpressionExecutor(expression.Right).execute(environment);
                    environment.SetVariant(expression.Left.Name, rightObject);
                    return rightObject;
                }
            }

            ScriptObject left = new ScriptExpressionExecutor(expression.Left).execute(environment);
            ScriptObject right = new ScriptExpressionExecutor(expression.Right).execute(environment);
            if (expression.Operation == Operation.Add)
            {
                return executeAdd(environment, left, right);
            }
            if (expression.Operation == Operation.Minus)
            {
                return executeMinus(environment, left, right);
            }
            if (expression.Operation == Operation.Mutiply)
            {
                return executeMutiply(environment, left, right);
            }
            if (expression.Operation == Operation.Divide)
            {
                return executeDivide(environment, left, right);
            }
            if (expression.Operation == Operation.Power)
            {
                return executePower(environment, left, right);
            }
            if (expression.Operation == Operation.Mode)
            {
                return executeMode(environment, left, right);
            }
            if (expression.Operation == Operation.DoubleEqual)
            {
                return executeDoubleEqual(environment, left, right);
            }
            if (expression.Operation == Operation.TripleEqual)
            {
                return executeTripleEqual(environment, left, right);
            }

            throw new Exception("Unkown operation.");
        }

        protected ScriptObject executeFunction(ScriptEnvironment environment)
        {
            if (!environment.IsFunction(expression.Name))
            {
                throw new Exception("Function '" + expression.Name + "' not found error.");
            }
            ScriptFunctionArgument funcArgument = expression.Right as ScriptFunctionArgument;
            ScriptObject[] argument = null;
            if (funcArgument.Argument != null)
            {
                argument = new ScriptObject[funcArgument.Argument.Length];
                for (int i = 0; i < funcArgument.Argument.Length; i++)
                {
                    argument[i] = new ScriptExpressionExecutor(funcArgument.Argument[i]).execute(environment);
                }
            }
            return environment.Function.GetValue(expression.Name).execute(environment, argument);
        }

        protected ScriptObject executeConstantVariant(ScriptEnvironment environment)
        {
            if (environment.IsConstantOrVariant(expression.Name))
            {
                return environment.GetValue(expression.Name);
            }
            else
            {
                throw new Exception("Constant or variant '" + expression.Name + "' not found error.");
            }
        }

        protected ScriptObject executeAdd(ScriptEnvironment environment, ScriptObject left, ScriptObject right)
        {
            if (left.IsString || right.IsString)
            {
                return new ScriptObject(ObjectType.String, (left.StringValue + right.StringValue));
            }
            return new ScriptObject(ObjectType.Number, (left.NumberValue + right.NumberValue));
        }

        protected ScriptObject executeMinus(ScriptEnvironment environment, ScriptObject left, ScriptObject right)
        {
            return new ScriptObject(ObjectType.Number, (left.NumberValue - right.NumberValue));
        }

        protected ScriptObject executeMutiply(ScriptEnvironment environment, ScriptObject left, ScriptObject right)
        {
            return new ScriptObject(ObjectType.Number, (left.NumberValue * right.NumberValue));
        }

        protected ScriptObject executeDivide(ScriptEnvironment environment, ScriptObject left, ScriptObject right)
        {
            return new ScriptObject(ObjectType.Number, (left.NumberValue / right.NumberValue));
        }

        protected ScriptObject executePower(ScriptEnvironment environment, ScriptObject left, ScriptObject right)
        {
            return new ScriptObject(ObjectType.Number, (Math.Pow(left.NumberValue, right.NumberValue)));
        }

        protected ScriptObject executeMode(ScriptEnvironment environment, ScriptObject left, ScriptObject right)
        {
            return new ScriptObject(ObjectType.Number, (Math.Round(left.NumberValue) % Math.Round(right.NumberValue)));
        }

        protected ScriptObject executeDoubleEqual(ScriptEnvironment environment, ScriptObject left, ScriptObject right)
        {
            if (left.IsNull || left.IsUndefined)
            {
                return new ScriptObject(ObjectType.Boolean, (left.IsNull || left.IsUndefined));
            }
            if (left.Type == ObjectType.Object)
            {
                return new ScriptObject(ObjectType.Boolean, false);
            }
            return new ScriptObject(ObjectType.Boolean, (left.StringValue == right.StringValue));
        }

        protected ScriptObject executeTripleEqual(ScriptEnvironment environment, ScriptObject left, ScriptObject right)
        {
            if (left.Type != right.Type)
            {
                return new ScriptObject(ObjectType.Boolean, false);
            }
            if (left.Type == ObjectType.Object)
            {
                return new ScriptObject(ObjectType.Boolean, false);
            }
            return new ScriptObject(ObjectType.Boolean, (left.StringValue == right.StringValue));
        }
    }
}
