﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace CommonScriptEnginer
{
    public class ScriptExpressionParser
    {
        private string expression;

        private List<string> expressionList = new List<string>();

        private bool inQoute = false;

        private char qouteChar = (char)0;

        private string lastStrBlock = "";

        private char lastChar = (char)0;

        private int bracketDepth = 0;

        protected ScriptExpressionParser(string expression)
        {
            this.expression = expression;
        }

        protected void parseToExpressionList()
        {
            for (int i = 0; i < expression.Length; i++)
            {
                char c = expression[i];
                if ((c == '"') || (c == '\''))
                {
                    if (inQoute)
                    {
                        if (qouteChar == c)
                        {
                            lastStrBlock += c;
                            inQoute = false;
                            qouteChar = (char)0;
                            expressionList.Add(lastStrBlock);
                            lastStrBlock = "";
                        }
                        else
                        {
                            lastStrBlock += c;
                        }
                    }
                    else
                    {
                        if (lastStrBlock.Length > 0)
                        {
                            expressionList.Add(lastStrBlock);
                        }
                        lastStrBlock += c;
                        inQoute = true;
                        qouteChar = c;
                    }
                    lastChar = c;
                    continue;
                }
                if (inQoute)
                {
                    if ((c == '\r') || (c == '\n'))
                    {
                        throw new Exception("Error new line.");
                    }
                    lastStrBlock += c;
                    lastChar = c;
                    continue;
                }
                if (IsBlankChar(c))
                {
                    if (!IsBlankChar(lastChar))
                    {
                        if (lastStrBlock.Length > 0)
                        {
                            expressionList.Add(lastStrBlock);
                        }
                        lastStrBlock = "";
                    }
                }
                else if ((c >= '0') && (c <= '9'))
                {
                    lastStrBlock += c;
                }
                else  if (((c >= 'a') && (c <= 'z')) || ((c >= 'A') && (c <= 'Z')) || (c == '_') || (c == '$'))
                {
                    lastStrBlock += c;
                }
                else if (IsMathMark("" + c))
                {
                    if (lastStrBlock.Length > 0)
                    {
                        expressionList.Add(lastStrBlock);
                    }
                    expressionList.Add("" + c);
                    lastStrBlock = "";
                }
                else if (c == '(')
                {
                    if (lastStrBlock.Length > 0)
                    {
                        expressionList.Add(lastStrBlock);
                        lastStrBlock = "";
                    }
                    expressionList.Add("(");
                    bracketDepth += 1;
                }
                else if (c == ')')
                {
                    if (bracketDepth == 0)
                    {
                        throw new Exception("Bracke error.");
                    }
                    if (lastStrBlock.Length > 0)
                    {
                        expressionList.Add(lastStrBlock);
                        lastStrBlock = "";
                    }
                    expressionList.Add(")");
                    bracketDepth -= 1;
                }
                else if (c == ',')
                {
                    expressionList.Add(lastStrBlock);
                    expressionList.Add(",");
                    lastStrBlock = "";
                }
                else if (c == '=')
                {
                    char nextc = ((i + 1) < expression.Length) ? expression[i + 1] : (char)0;
                    char nextnextc = ((i + 2) < expression.Length) ? expression[i + 2] : (char)0;
                    if (nextc == '=')
                    {
                        if (nextnextc == '=')
                        {
                            if (lastStrBlock.Length > 0)
                            {
                                expressionList.Add(lastStrBlock);
                            }
                            expressionList.Add("===");
                            lastStrBlock = "";
                            i += 2;
                        }
                        else
                        {
                            if (lastStrBlock.Length > 0)
                            {
                                expressionList.Add(lastStrBlock);
                            }
                            expressionList.Add("==");
                            lastStrBlock = "";
                            i += 1;
                        }
                    }
                    else
                    {
                        if (lastStrBlock.Length > 0)
                        {
                            expressionList.Add(lastStrBlock);
                        }
                        expressionList.Add("=");
                        lastStrBlock = "";
                    }
                }
                else
                {
                    lastStrBlock += c;
                }
                lastChar = c;
            }

            if (bracketDepth != 0)
            {
                throw new Exception("Bracket error.");
            }

            if (inQoute)
            {
                throw new Exception("Qoute error.");
            }

            if (lastStrBlock.Length > 0)
            {
                expressionList.Add(lastStrBlock);
            }
        }

        protected static ScriptExpression parseToExpressionTree(List<string> expressionList)
        {
            if (expressionList.Count == 0)
            {
                return ScriptExpression.EmptyExpression;
            }
            if (expressionList.Count == 1)
            {
                return parseToExpression(expressionList[0]);
            }
            if ((expressionList[0] == "(") && (expressionList[expressionList.Count - 1] == ")"))
            {
                List<string> subExpressionList = new List<string>();
                for (int i = 1; i < (expressionList.Count - 1); i++)
                {
                    subExpressionList.Add(expressionList[i]);
                }
                return parseToExpressionTree(subExpressionList);
            }
            List<NameOrList> nameOrList = ConvertToExpressionMapList(expressionList);
            int index = GetMostPiorMarkIndex(nameOrList);

            if (index >= 0)
            {
                Operation operation = ScriptOperation.GetOperationByName(nameOrList[index].Name);
                ScriptExpression left = parseToExpressionTree(ConvertToExpressionList(nameOrList, true, index));
                ScriptExpression right = parseToExpressionTree(ConvertToExpressionList(nameOrList, false, index));
                return new ScriptExpression(operation, left, right);
            }

            if (IsFunctionExpression(expressionList))
            {
                string funcName = expressionList[0];

                return new ScriptExpression(Operation.Function, funcName, null, ParseFunctionArgument(expressionList));
            }

            if ((expressionList.Count == 2) && (expressionList[0] == "goto"))
            {
                if (!IsConstVarOrFuncExpression(expressionList[1]))
                {
                    throw new Exception("Goto expression error.");
                }
                return new ScriptExpression(Operation.Goto, expressionList[1], null, null);
            }

            // other TODO ...

            return null;
        }

        protected static ScriptFunctionArgument ParseFunctionArgument(List<string> expressionList)
        {
            List<string> subExpressionList = new List<string>();
            for (int i = 2; i < (expressionList.Count - 1); i++)
            {
                subExpressionList.Add(expressionList[i]);
            }
            List<NameOrList> subNameOrListList = ConvertToExpressionMapList(subExpressionList);

            List<List<string>> argumentExpressionList = new List<List<string>>();
            List<string> argList = new List<string>();
            for (int i = 0; i < subNameOrListList.Count; i++)
            {
                if (subNameOrListList[i].Name == ",")
                {
                    argumentExpressionList.Add(argList);
                    argList = new List<string>();
                }
                else
                {
                    if (subNameOrListList[i].Name != null)
                    {
                        argList.Add(subNameOrListList[i].Name);
                    }
                    else
                    {
                        for (int j = 0; j < subNameOrListList[i].List.Count; j++)
                        {
                            argList.Add(subNameOrListList[i].List[j]);
                        }
                    }
                }
            }
            argumentExpressionList.Add(argList);
            if (argumentExpressionList.Count == 0)
            {
                return new ScriptFunctionArgument(null);
            }
            ScriptExpression[] argumentExpression = new ScriptExpression[argumentExpressionList.Count];

            for (int i = 0; i < argumentExpressionList.Count; i++)
            {
                argumentExpression[i] = parseToExpressionTree(argumentExpressionList[i]);
            }

            return new ScriptFunctionArgument(argumentExpression);
        }

        protected static bool IsFunctionExpression(List<string> expressionList)
        {
            if (expressionList.Count >= 3)
            {
                if (IsConstVarOrFuncExpression(expressionList[0]))
                {
                    if ((expressionList[1] == "(") && (expressionList[expressionList.Count - 1] == ")"))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        protected static int GetMostPiorMarkIndex(List<NameOrList> nameOrList)
        {
            int index = -1;

            List<List<string>> operationGroupList = ScriptOperation.OperationGroupList;
            for (int i = 0; i < operationGroupList.Count; i++)
            {
                List<string> operationGroup = operationGroupList[i];

                if (operationGroup[0] == "=")
                {
                    for (int j = 0; j < operationGroup.Count; j++)
                    {
                        int idx = nameOrList.IndexOf(new NameOrList(operationGroup[j]));
                        index = (index < 0) ? idx : Math.Min(index, idx);
                    }
                }
                else
                {
                    for (int j = 0; j < operationGroup.Count; j++)
                    {
                        int idx = nameOrList.LastIndexOf(new NameOrList(operationGroup[j]));
                        index = Math.Max(index, idx);
                    }
                }
                if (index >= 0)
                {
                    return index;
                }
            }

            return -1;
        }

        protected static ScriptExpression parseToExpression(string expression)
        {
            if ((expression[0] == '\'') || (expression[0] == '"'))
            {
                return new ScriptObject(ObjectType.String, expression.Substring(1, (expression.Length - 2)));
            }
            if (expression == "true")
            {
                return ScriptObject.True;
            }
            if (expression == "false")
            {
                return ScriptObject.False;
            }
            if (expression == "null")
            {
                return ScriptObject.Null;
            }
            if (IsNumberExpression(expression))
            {
                return new ScriptObject(ObjectType.Number, Double.Parse(expression));
            }
            if (IsConstVarOrFuncExpression(expression))
            {
                return new ScriptExpression(Operation.ConstVar, expression, null, null);
            }
            throw new Exception("Unknown expression.");
        }

        protected static List<string> ConvertToExpressionList(List<NameOrList> nameOrListList, bool firstBlock, int index)
        {
            List<string> expresionList = new List<string>();
            int from = firstBlock ? 0 : (index + 1);
            int to = firstBlock ? index : nameOrListList.Count;
            for (int i = from; i < to; i++)
            {
                NameOrList nameOrList = nameOrListList[i];
                if (nameOrList.Name != null)
                {
                    expresionList.Add(nameOrList.Name);
                }
                else
                {
                    for (int j = 0; j < nameOrList.List.Count; j++)
                    {
                        expresionList.Add(nameOrList.List[j]);
                    }
                }
            }
            return expresionList;
        }

        protected static List<NameOrList> ConvertToExpressionMapList(List<string> expressionList)
        {
            List<NameOrList> nameOrListList = new List<NameOrList>();

            int bracketDepth = 0;
            List<string> listList = new List<string>();
            
            for (int i = 0; i < expressionList.Count; i++)
            {
                string expression = expressionList[i];
                if (expression == "(")
                {
                    listList.Add(expression);
                    bracketDepth += 1;
                }
                else if (expression == ")")
                {
                    listList.Add(expression);
                    bracketDepth -= 1;
                    if (bracketDepth == 0)
                    {
                        nameOrListList.Add(new NameOrList(listList));
                        listList = new List<string>();
                    }
                }
                else
                {
                    if (bracketDepth > 0)
                    {
                        listList.Add(expression);
                    }
                    else
                    {
                        nameOrListList.Add(new NameOrList(expression));
                    }
                }
            }

            return nameOrListList;
        }

        public static ScriptExpression ParseExpression(string expression)
        {
            if (String.IsNullOrEmpty((expression == null) ? null : expression.Trim()))
            {
                return ScriptExpression.EmptyExpression;
            }
            ScriptExpressionParser parser = new ScriptExpressionParser(expression);
            parser.parseToExpressionList();
            return parseToExpressionTree(parser.expressionList);
        }

        protected static bool IsBlankChar(char c)
        {
            return ((c == ' ') || (c == '\r') || (c == '\n') || (c == '\t'));
        }

        protected static bool IsMathMark(string ex)
        {
            return ((ex == "+") || (ex == "-") || (ex == "*") || (ex == "/") || (ex == "^") || (ex == "%"));
        }

        protected static bool IsNumberExpression(string expression)
        {
            return new Regex(@"^(\d+(\.\d*)?)|(\.\d+)$").IsMatch(expression);
        }

        protected static bool IsConstVarOrFuncExpression(string expression)
        {
            return new Regex(@"^[_$a-zA-Z][_$a-zA-Z0-9]*$").IsMatch(expression);
        }
    }

    public class NameOrList
    {
        private string name;

        private List<string> list;

        public NameOrList(string name)
        {
            this.name = name;
            this.list = null;
        }

        public override bool Equals(object obj)
        {
            NameOrList anotherObj = (NameOrList)obj;
            return ((this.name == anotherObj.name) && (this.list == anotherObj.list));
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public NameOrList(List<string> list)
        {
            this.name = null;
            this.list = list;
        }

        public string Name
        {
            get { return name; }
        }

        public List<string> List
        {
            get { return list; }
        }
    }
}
