﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class ScriptFileLoader
    {
        public static ScriptBlock LoadScriptBlock(string script)
        {
            List<ScriptLine> scriptLines = new List<ScriptLine>();
            Hashtable labelMap = new Hashtable();

            string[] lines = script.Split('\n');

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                string trimLine = (String.IsNullOrEmpty(line)) ? "" : line.Trim();
                if ((trimLine.Length > 1) && trimLine.EndsWith(":"))
                {
                    if (!ScriptUtility.IsConstVarOrFuncExpression(trimLine.Substring(0, (trimLine.Length - 1))))
                    {
                        throw new Exception("Label error.");
                    }
                    labelMap.Add(trimLine, i);
                    line = "";
                }
                scriptLines.Add(new ScriptLine(i, line));
            }

            return new ScriptBlock(scriptLines, labelMap);
        }
    }
}
