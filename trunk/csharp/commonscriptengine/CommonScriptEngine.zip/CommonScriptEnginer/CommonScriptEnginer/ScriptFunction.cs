﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class ScriptFunction
    {
        public delegate ScriptObject BuildInFunction(ScriptEnvironment environment, ScriptObject[] argument);

        protected bool buildIn;

        BuildInFunction buildInFunction;

        protected string funcName;

        protected string[] parameter;

        protected string[] body;

        public ScriptFunction(string funcName, BuildInFunction buildInFunction)
        {
            this.buildIn = true;
            this.funcName = funcName;
            this.buildInFunction = buildInFunction;
        }

        public ScriptFunction(string whole)
        {
            this.buildIn = false;
        }

        protected void ParseFunction(string whole)
        {
            // TODO 
        }

        public bool BuildIn
        {
            get { return buildIn; }
        }

        public string FuncName
        {
            get { return funcName; }
        }

        public ScriptObject execute(ScriptEnvironment environment, ScriptObject[] argument)
        {
            ScriptEnvironment execEnvironment = ScriptEnvironment.FromGlobalEnvironment(environment);
            if (parameter != null)
            {
                for (int i = 0; i < parameter.Length; i++)
                {
                    if ((argument != null) && (argument.Length > i))
                    {
                        execEnvironment.CurrentVariant.SetValue(parameter[i], argument[i]);
                    }
                    else
                    {
                        execEnvironment.CurrentVariant.SetValue(parameter[i], ScriptObject.Undefined);
                    }
                }
            }
            if (buildIn)
            {
                return buildInFunction(environment, argument);
            }
            if (body != null)
            {
                for (int i = 0; i < body.Length; i++)
                {
                    string line = body[i];
                    ScriptExpressionExecutor expressionExecutor = new ScriptExpressionExecutor(line);
                    ScriptObject result = expressionExecutor.execute(execEnvironment);
                    if (expressionExecutor.IsReturn())
                    {
                        return result;
                    }
                }
            }

            return ScriptObject.Undefined;
        }
    }
}
