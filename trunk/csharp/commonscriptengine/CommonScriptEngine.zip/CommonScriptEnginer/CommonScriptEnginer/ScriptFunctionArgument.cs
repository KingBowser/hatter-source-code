﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class ScriptFunctionArgument: ScriptExpression
    {
        protected ScriptExpression[] argument;

        public ScriptFunctionArgument(ScriptExpression[] argument)
        {
            this.operation = Operation.Argument;
            this.argument = argument;
        }

        public ScriptExpression[] Argument
        {
            get { return argument; }
        }
    }
}
