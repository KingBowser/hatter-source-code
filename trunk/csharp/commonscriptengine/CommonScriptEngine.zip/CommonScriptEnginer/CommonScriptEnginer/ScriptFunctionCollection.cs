﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class ScriptFunctionCollection: PairCollection<String, ScriptFunction>
    {
        public void AddFunction(ScriptFunction function)
        {
            SetValue(function.FuncName, function);
        }
    }
}
