﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class ScriptGoto: ScriptObject
    {
        private string label;

        public ScriptGoto(string label): base(ObjectType.Undefined, null)
        {
            this.label = label;
        }

        public string Label
        {
            get { return label; }
        }
    }
}
