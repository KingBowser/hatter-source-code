﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class ScriptKeyWords
    {
        private static List<string> keyWords = new List<string>();
        static ScriptKeyWords()
        {
            keyWords.Add("var");
            keyWords.Add("if");
            keyWords.Add("else");
            keyWords.Add("for");
            keyWords.Add("in");
            keyWords.Add("while");
            keyWords.Add("do");
            keyWords.Add("function");
            keyWords.Add("return");
            keyWords.Add("try");
            keyWords.Add("catch");
            keyWords.Add("throw");
            keyWords.Add("new");
            keyWords.Add("null");
            keyWords.Add("instanceof");
            keyWords.Add("true");
            keyWords.Add("false");
            keyWords.Add("this");
            keyWords.Add("goto");
            keyWords.Add("typeof");
            keyWords.Add("switch");
            keyWords.Add("case");
            keyWords.Add("default");
            keyWords.Add("delete");
        }

        public static bool IsKeyWord(string key)
        {
            return keyWords.Contains(key);
        }
    }
}
