﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class ScriptLine
    {
        private int number;

        private string line;

        public ScriptLine(int number, string line)
        {
            this.number = number;
            this.line = line;
        }

        public int Number
        {
            get { return number; }
        }

        public string Line
        {
            get { return line; }
        }
    }
}
