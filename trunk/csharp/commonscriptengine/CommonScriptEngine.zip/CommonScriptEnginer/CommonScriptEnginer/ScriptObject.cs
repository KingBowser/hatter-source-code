﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class ScriptObject: ScriptExpression
    {
        protected ObjectType type;

        protected object value;

        public ScriptObject(ObjectType type, object value)
        {
            this.operation = Operation.Value;
            this.type = type;
            this.value = value;
        }

        public ObjectType Type
        {
            get { return this.type; }
        }

        public object Value
        {
            get { return this.value; }
        }

        public string StringValue
        {
            get
            {
                if (IsNull)
                {
                    return "null";
                }
                else if (IsUndefined)
                {
                    return "undefined";
                } if (IsBoolean)
                {
                    return ((bool)value) ? "true" : "false";
                }
                else
                {
                    return "" + value;
                }
            }
        }

        public double NumberValue
        {
            get
            {
                if (IsNull || IsUndefined)
                {
                    return 0;
                }
                if (IsBoolean)
                {
                    return (bool)value ? 1 : 0;
                }
                if (IsNumber)
                {
                    return (double)value;
                }
                if (IsString)
                {
                    return Double.Parse((string)value);
                }
                throw new Exception("Cannot convert to number type.");
            }
        }

        public int IntegerValue
        {
            get { return (int)NumberValue; }
        }

        public bool BooleanValue
        {
            get { return IsTrue; }
        }

        public bool IsTrue
        {
            get
            {
                if (IsNull || IsUndefined)
                {
                    return false;
                }
                if (IsBoolean)
                {
                    return (bool) value;
                }
                if (IsNumber)
                {
                    return ((double)value != 0);
                }
                if (IsString)
                {
                    return !String.IsNullOrEmpty(value as string);
                }
                if (IsObject)
                {
                    return (value != null);
                }
                throw new Exception("Unknow object type.");
            }
        }

        public bool IsNull
        {
            get { return (type == ObjectType.Null); }
        }

        public bool IsUndefined
        {
            get { return (type == ObjectType.Undefined); }
        }

        public bool IsBoolean
        {
            get { return (type == ObjectType.Boolean); }
        }

        public bool IsString
        {
            get { return (type == ObjectType.String); }
        }

        public bool IsNumber
        {
            get { return (type == ObjectType.Number); }
        }

        public bool IsObject
        {
            get { return (type == ObjectType.Object); }
        }

        public static readonly ScriptObject Undefined = new ScriptObject(ObjectType.Undefined, null);

        public static readonly ScriptObject Null = new ScriptObject(ObjectType.Null, null);

        public static readonly ScriptObject True = new ScriptObject(ObjectType.Boolean, true);

        public static readonly ScriptObject False = new ScriptObject(ObjectType.Boolean, false);

        public static readonly ScriptObject Empty = new ScriptObject(ObjectType.String, "");
    }

}
