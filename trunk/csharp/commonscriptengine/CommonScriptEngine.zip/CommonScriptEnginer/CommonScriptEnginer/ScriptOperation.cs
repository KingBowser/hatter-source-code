﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public class ScriptOperation
    {
        private static List<string> operationName = new List<string>();

        private static List<Operation> operationEnum = new List<Operation>();

        private static List<List<string>> operationGroupList = new List<List<string>>();

        static ScriptOperation()
        {
            operationName.Add("+"); operationEnum.Add(Operation.Add);
            operationName.Add("-"); operationEnum.Add(Operation.Minus);
            operationName.Add("*"); operationEnum.Add(Operation.Mutiply);
            operationName.Add("/"); operationEnum.Add(Operation.Divide);
            operationName.Add("%"); operationEnum.Add(Operation.Mode);
            operationName.Add("^"); operationEnum.Add(Operation.Power);
            operationName.Add("="); operationEnum.Add(Operation.Equal);
            operationName.Add("=="); operationEnum.Add(Operation.DoubleEqual);
            operationName.Add("==="); operationEnum.Add(Operation.TripleEqual);

            List<string> group;

            group = new List<string>();
            group.Add("=");
            operationGroupList.Add(group);

            group = new List<string>();
            group.Add("==");
            group.Add("===");
            operationGroupList.Add(group);
            
            group = new List<string>();
            group.Add("+");
            group.Add("-");
            operationGroupList.Add(group);

            group = new List<string>();
            group.Add("*");
            group.Add("/");
            group.Add("%");
            operationGroupList.Add(group);

            group = new List<string>();
            group.Add("^");
            operationGroupList.Add(group);
        }

        public static List<List<string>> OperationGroupList
        {
            get { return operationGroupList; }
        }

        public static Operation GetOperationByName(string name)
        {
            return operationEnum[operationName.IndexOf(name)];
        }
    }
}
