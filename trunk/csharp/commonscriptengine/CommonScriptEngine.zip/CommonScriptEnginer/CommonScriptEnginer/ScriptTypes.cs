﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonScriptEnginer
{
    public enum Operation
    {
        Empty,

        Goto,

        Value,

        Function,

        Argument,

        ConstVar,

        Add,

        Minus,

        Mutiply,

        Divide,

        Mode,

        Power,

        Return,

        Equal,

        DoubleEqual,

        TripleEqual,

        GreaterThan,

        LittleThan,

        GreaterEqualThan,

        LittleEqualThan,

        BitAnd,

        LogicAnd,

        BitOr,

        LogicOr,

        NotOr
    }

    public enum ObjectType
    {
        Undefined,

        Null,

        Object,

        Boolean,

        Number,

        String
    }
}
