﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace CommonScriptEnginer
{
    public class ScriptUtility
    {
        public static bool IsNumberExpression(string expression)
        {
            return new Regex(@"^(\d+(\.\d*)?)|(\.\d+)$").IsMatch(expression);
        }

        public static bool IsConstVarOrFuncExpression(string expression)
        {
            return new Regex(@"^[_$a-zA-Z][_$a-zA-Z0-9]*$").IsMatch(expression);
        }
    }
}
