/**
 * 
 */
package net.winstone.boot;

/**
 * ServerConfigurationParser.
 * 
 * @author <a href="mailto:jguibert@intelligents-ia.com" >Jerome Guibert</a>
 * 
 */
public class ServerConfigurationParser {

}
