/**
 * 
 */
package net.winstone;

/**
 * DebugApplication.
 * 
 * @author <a href="mailto:jguibert@intelligents-ia.com" >Jerome Guibert</a>
 * 
 */
public class DebugApplication {

	/**
	 * @param args
	 */
	public static void main(final String[] args) {

		Winstone.main(new String[] { "--warfile=..\\test-webapp\\target\\test-webapp.war" });

	}

}
